<nav class="navbar navbar-inverse header_block">
  <div class="container-fluid navbar_align">
    <div class="navbar-header">
      <a class="navbar-brand" href="Index.php">bongda.vn</a>
    </div>
       <ul class="nav navbar-nav">
      <li class="active"><a href="Index.php">Trang chủ</a></li>
      <li><a href="Anh.php">Anh</a></li>
      <li><a href="TBN.php">TBN</a></li>
      <li><a href="Phap.php">Pháp</a></li>
      <li><a href="Duc.php">Đức</a></li>
      <li><a href="Y.php">Ý</a></li>
      <li><a href="C1.php">Champion League</a></li>
      <li><a href="ChuyenNhuong.php">Chuyển nhượng</a></li>
      <li><a href="LichThiDau.php">Lịch thi đấu</a></li>
      <li><a href="TimKiem.php">Tìm kiếm</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="DangNhap.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>